fs=10000 %% sampling frequency
f1=500;  %% first sinewave freq (in band)
f2=4500; %% second sinewave freq (out band)

N=2; %% filter order
nb=9; %% number of bits

T=1/500; %% maximum period
tt=0:1/fs:10*T; %% time samples

x1=sin(2*pi*f1*tt); %% first sinewave
x2=sin(2*pi*f2*tt); %% second sinewave

x=(x1+x2)/2; %% input signal

[bi, ai, bq, aq]=myiir_lookahead_design(N, nb) %% filter design

y=filter(bq, aq, x); %% apply filter

%% plots
figure
plot(tt,x1,'--d');
hold on
plot(tt,x2,'r--s');
plot(tt,x, 'g--+');
plot(tt, y, 'c--o');

legend('x1', 'x2', 'x', 'y')

%% quantize input and output
% convert x samples from -1:1 to -256:256 range
xq=floor(x*2^(nb-1)); 
% take indexes of samples equal to 256...
idx=find(xq==2^(nb-1)); 
% ...and decrement the value of these samples,
% the maximum value on 8 bits is 255
xq(idx)=2^(nb-1)-1; 

yq=floor(y*2^(nb-1));
idy=find(yq==2^(nb-1));
yq(idy)=2^(nb-1)-1;

%% save input and output
% inputs are saved on samples.txt
fp=fopen('samples.txt','w');
fprintf(fp,'%d\n', xq);
fclose(fp);

% outputs are saved on resultsm.txt
fp=fopen('resultsm_la.txt', 'w');
fprintf(fp, '%d\n', yq);
fclose(fp);

%% read outputs provided from C reference model
% outputs are saved inside yq_c
results_c='..\..\..\..\OneDrive - Politecnico di Torino\5° Anno\Integrated Systems Architecture\Labs\Lab1\resultsc_la.txt';
fp=fopen(results_c, 'r');
yq_c=fscanf(fp, '%d\n');
fclose(fp);

% outputs with less bits are saved inside yq_optc
% these are the outputs with reduced resolution and
% area of the filter
results_optc='..\..\..\..\OneDrive - Politecnico di Torino\5° Anno\Integrated Systems Architecture\Labs\Lab1\resultsoptc_la.txt';
fp=fopen(results_optc, 'r');
yq_optc=fscanf(fp, '%d\n');
fclose(fp);

%% thd evaluation for matlab and C reference models
% matlab case
disp '-----Total harmonic distortion evaluation-----'
thd_m=thd(yq,fs)

% C case
thd_c=thd(yq_c,fs)

% C optimized case
% thd_optc = -36.3743 dB
disp '-----Optimized case (SHAMT=10, 10 bits discarded after mpy)-----'
thd_optc=thd(yq_optc, fs)

%% representation of filter transfer function
disp '-----Transfer function-----'
Hz=filt(bq,aq,1/fs)


%% convert integer coefficients to binary
disp '-----Integer to binary conversion-----'
dec2bin(ai,9)
dec2bin(bi,9)
